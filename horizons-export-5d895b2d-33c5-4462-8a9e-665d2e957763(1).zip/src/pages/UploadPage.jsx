import React from 'react';

const UploadPage = () => {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <h1 className="text-2xl font-bold">Esta página ha sido reemplazada por /order</h1>
    </div>
  );
};

export default UploadPage;